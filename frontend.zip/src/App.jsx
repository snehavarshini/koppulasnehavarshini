import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';

// Common
import Home from './Components/Home';
import Footer from './Components/Footer';

// Admin
import Asignup from './Admin/Asignup';
import Alogin from './Admin/Alogin';
import Ahome from './Admin/Ahome';
import Users from './Admin/Users';
import Seller from './Admin/Seller';

// Seller
import Ssignup from './Seller/Ssignup';
import Slogin from './Seller/Slogin';
import Shome from './Seller/Shome';
import MyProducts from './Seller/MyProducts';
import Addbook from './Seller/Addbook';
import Orders from './Seller/Orders';

// User
import Signup from './User/Signup';
import Login from './User/Login';
import Uhome from './User/Uhome';
import Products from './User/Products';
import Uitem from './User/Uitem';
import MyOrders from './User/MyOrders';

function App() {
  return (
    <BrowserRouter>
      <Routes>

        {/* Home — no background */}
        <Route path="/" element={<Home />} />

        {/* All other pages — with blurred book background */}
        <Route path="/*" element={
          <div className="page-wrapper">
            <div className="bg-overlay" />
            <div style={{ position: 'relative', zIndex: 1 }}>
              <Routes>
                <Route path="/admin/signup" element={<Asignup />} />
                <Route path="/admin/login" element={<Alogin />} />
                <Route path="/admin/home" element={<Ahome />} />
                <Route path="/admin/users" element={<Users />} />
                <Route path="/admin/sellers" element={<Seller />} />

                <Route path="/seller/signup" element={<Ssignup />} />
                <Route path="/seller/login" element={<Slogin />} />
                <Route path="/seller/home" element={<Shome />} />
                <Route path="/seller/products" element={<MyProducts />} />
                <Route path="/seller/addbook" element={<Addbook />} />
                <Route path="/seller/orders" element={<Orders />} />

                <Route path="/user/signup" element={<Signup />} />
                <Route path="/user/login" element={<Login />} />
                <Route path="/user/home" element={<Uhome />} />
                <Route path="/user/books" element={<Products />} />
                <Route path="/user/books/:id" element={<Uitem />} />
                <Route path="/user/orders" element={<MyOrders />} />

                <Route path="*" element={<Navigate to="/" />} />
              </Routes>
            </div>
          </div>
        } />

      </Routes>
    </BrowserRouter>
  );
}

export default App;
