import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Unavbar from "./Unavbar";
import Footer from "../Components/Footer";

const TOP_RECOMMENDATIONS = [
  {
    _id: 1,
    title: "Atomic Habits",
    image: "https://images-na.ssl-images-amazon.com/images/I/91bYsX41DVL.jpg",
  },
  {
    _id: 2,
    title: "The Psychology of Money",
    image: "https://images-na.ssl-images-amazon.com/images/I/71g2ednj0JL.jpg",
  },
  {
    _id: 3,
    title: "Ikigai",
    image: "https://images-na.ssl-images-amazon.com/images/I/81l3rZK4lnL.jpg",
  },
  {
    _id: 4,
    title: "The Alchemist",
    image: "https://images-na.ssl-images-amazon.com/images/I/71aFt4+OTOL.jpg",
  },
];

const PLACEHOLDER_BOOKS = [
  {
    title: "Atomic Habits",
    cover: "https://images-na.ssl-images-amazon.com/images/I/91bYsX41DVL.jpg",
  },

  {
    title: "Rich Dad Poor Dad",
    cover: "https://images-na.ssl-images-amazon.com/images/I/81bsw6fnUiL.jpg",
  },

  {
    title: "Think and Grow Rich",
    cover: "https://images-na.ssl-images-amazon.com/images/I/71UypkUjStL.jpg",
  },

  {
    title: "Harry Potter",
    cover: "https://images-na.ssl-images-amazon.com/images/I/81YOuOGFCJL.jpg",
  },

  {
    title: "The Psychology of Money",
    cover: "https://images-na.ssl-images-amazon.com/images/I/71g2ednj0JL.jpg",
  },

  {
    title: "Ikigai",
    cover: "https://images-na.ssl-images-amazon.com/images/I/81l3rZK4lnL.jpg",
  },

  {
    title: "The Alchemist",
    cover: "https://images-na.ssl-images-amazon.com/images/I/71aFt4+OTOL.jpg",
  },

  {
    title: "Deep Work",
    cover: "https://images-na.ssl-images-amazon.com/images/I/71QKQ9mwV7L.jpg",
  },
];

export default function Uhome() {
  const [books, setBooks] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("/api/user/books")
      .then((res) => setBooks(res.data))
      .catch(() => {});
  }, []);

  return (
  <div
    style={{
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      background: "var(--bg)",
    }}
  >
    <Unavbar />

    <div style={{ flex: 1 }}>
      {/* Best Sellers */}
      <h2 className="section-title">Best Seller</h2>

      <div className="slider">
        <div className="slider-track">
          {[...PLACEHOLDER_BOOKS, ...PLACEHOLDER_BOOKS].map((b, i) => (
            <div className="bestseller-item" key={i}>
              <img
                src={b.cover}
                alt={b.title}
                onError={(e) => {
                  e.target.src = "";
                  e.target.style.background = "var(--secondary)";
                }}
              />
              <p>{b.title}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Top Recommendation */}
      <h2 className="section-title">Top Recommendation</h2>

      <div className="bestseller-grid">
        {(books.length > 0 ? books.slice(0, 4) : TOP_RECOMMENDATIONS).map(
          (book) => (
            <div
              className="bestseller-item"
              key={book._id}
              onClick={() =>
                books.length > 0 && navigate(`/user/books/${book._id}`)
              }
            >
              <img
                src={
                  books.length > 0
                    ? `http://localhost:8000/uploads/${book.itemImage}`
                    : book.image
                }
                alt={book.title}
              />
              <p>{book.title}</p>
            </div>
          )
        )}
      </div>
    </div>

    <Footer />
  </div>
);
   
}
