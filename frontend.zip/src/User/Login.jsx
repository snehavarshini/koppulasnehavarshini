import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [err, setErr] = useState('');

  const handleSubmit = async () => {
    try {
      const res = await axios.post('/api/user/login', form);
      localStorage.setItem('userToken', res.data.token);
      localStorage.setItem('userName', res.data.name);
      navigate('/user/home');
    } catch (e) {
      setErr(e.response?.data?.message || 'Login failed');
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h2>Login to User Account</h2>
        {err && <p style={{ color: 'var(--danger)', textAlign: 'center', fontSize: '0.82rem', marginBottom: '0.75rem' }}>{err}</p>}
        <div className="form-group">
          <label>Email address</label>
          <input type="email" placeholder="Email address" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input type="password" placeholder="Password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
        </div>
        <button className="btn-primary" onClick={handleSubmit}>Log in</button>
        <p className="auth-footer">Don't have an account? Create <a href="/user/signup">Signup</a></p>
      </div>
    </div>
  );
}
