import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Unavbar from "./Unavbar";
import { toast } from "react-toastify";

export default function Products() {
  const [books, setBooks] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const res = await axios.get("/api/user/books");

      setBooks(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const buyBook = async (bookId) => {
    try {
      const token = localStorage.getItem("token");

      await axios.post(
        "/api/user/order",

        {
          bookId,
        },

        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      alert("Book Purchased Successfully");

      navigate("/user/orders");
    } catch (err) {
      toast.error(err.response?.data?.message || "Purchase Failed");
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)" }}>
      <Unavbar />

      <div className="products-page">
        <h2 className="section-title">Available Books</h2>

        <div className="books-grid">
          {books.map((book) => (
            <div className="book-card" key={book._id}>
              {book.itemImage ? (
                <img
                  src={`http://localhost:8000/uploads/${book.itemImage}`}
                  alt={book.title}
                />
              ) : (
                <div className="image-placeholder">📚</div>
              )}

              <h3>{book.title}</h3>

              <p>
                <b>Author :</b>

                {book.author}
              </p>

              <p>
                <b>Genre :</b>

                {book.genre}
              </p>

              <p>
                <b>Price :</b>₹ {book.price}
              </p>

              <div className="book-buttons">
                <button
                  className="hero-btn"
                  onClick={() => navigate(`/user/books/${book._id}`)}
                >
                  View
                </button>

                <button
                  className="contact-btn"
                  onClick={() => buyBook(book._id)}
                >
                  Buy Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
