import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Unavbar from './Unavbar';

export default function Uitem() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ flatno: '', pincode: '', city: '', state: '' });
  const [msg, setMsg] = useState('');
  const token = localStorage.getItem('userToken');

  useEffect(() => {
    axios.get(`/api/user/books/${id}`).then(res => setBook(res.data)).catch(() => {});
  }, [id]);

  const placeOrder = async () => {
    if (!token) { navigate('/user/login'); return; }
    try {
      await axios.post('/api/user/orders', {
        ...form,
        totalamount: book.price,
        booktitle: book.title,
        bookauthor: book.author,
        bookgenre: book.genre,
        itemImage: book.itemImage,
        description: book.description,
        sellerId: book.sellerId,
        sellerName: book.sellerName
      }, { headers: { Authorization: `Bearer ${token}` } });
      setMsg('Order placed successfully!');
      setTimeout(() => { setShowModal(false); navigate('/user/orders'); }, 1200);
    } catch (e) {
      setMsg(e.response?.data?.message || 'Failed to place order');
    }
  };

  if (!book) return <div style={{ minHeight: '100vh', background: 'var(--bg)' }}><Unavbar /><p style={{ textAlign: 'center', padding: '2rem' }}>Loading...</p></div>;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Unavbar />
      <div className="book-view-page">
        {book.itemImage
          ? <img className="book-view-img" src={`/uploads/${book.itemImage}`} alt={book.title} />
          : <div className="book-view-img" style={{ height: 320, background: 'var(--secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '5rem', borderRadius: 8 }}>📚</div>
        }

        <div className="book-view-cards">
          <div className="info-card">
            <h3>Description</h3>
            <p>{book.description || 'No description available.'}</p>
          </div>
          <div className="info-card">
            <h3>Info</h3>
            <p className="info-row"><strong>Title:</strong> {book.title}</p>
            <p className="info-row"><strong>Author:</strong> {book.author}</p>
            <p className="info-row"><strong>Genre:</strong> {book.genre}</p>
            <p className="info-row"><strong>Price:</strong> ₹{book.price}</p>
            <p className="info-row"><strong>Seller:</strong> {book.sellerName}</p>
          </div>
        </div>

        <button className="buy-btn" onClick={() => setShowModal(true)}>Buy Now</button>
      </div>

      {/* Buy Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-box" onClick={e => e.stopPropagation()}>
            <h3>Enter Delivery Address</h3>
            {msg && <p style={{ color: 'var(--primary)', textAlign: 'center', fontSize: '0.85rem', marginBottom: '0.75rem' }}>{msg}</p>}
            {[
              { key: 'flatno', label: 'Flat No / Street' },
              { key: 'city', label: 'City' },
              { key: 'pincode', label: 'Pincode' },
              { key: 'state', label: 'State' },
            ].map(f => (
              <div className="form-group" key={f.key}>
                <label>{f.label}</label>
                <input placeholder={f.label} value={form[f.key]} onChange={e => setForm({ ...form, [f.key]: e.target.value })} />
              </div>
            ))}
            <div className="modal-footer">
              <button className="btn-primary" style={{ width: 'auto', padding: '0.6rem 1.5rem' }} onClick={placeOrder}>Confirm Order</button>
              <button className="btn-danger btn-sm" style={{ padding: '0.6rem 1rem' }} onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
