import { useEffect, useState } from 'react';
import axios from 'axios';
import Unavbar from './Unavbar';

export default function MyOrders() {
  const [orders, setOrders] = useState([]);
  const token = localStorage.getItem('userToken');

  useEffect(() => {
    axios.get('/api/user/orders', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setOrders(res.data))
      .catch(() => {});
  }, []);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Unavbar />
      <div className="orders-page">
        <h2>My Orders</h2>
        {orders.length === 0 && <p style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No orders yet. <a href="/user/books">Browse books</a></p>}
        {orders.map(o => (
          <div className="order-card" key={o._id}>
            {o.itemImage
              ? <img src={`/uploads/${o.itemImage}`} alt={o.booktitle} />
              : <div style={{ width: 60, height: 80, background: 'var(--secondary)', borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.5rem', flexShrink: 0 }}>📚</div>
            }
            <div className="order-info">
              <div className="order-info-item"><label>Product Name</label><span>{o.booktitle}</span></div>
              <div className="order-info-item"><label>Order ID</label><span style={{ fontSize: '0.72rem' }}>{o._id.slice(0, 10)}...</span></div>
              <div className="order-info-item"><label>Address</label><span>{o.flatno}, {o.city} ({o.pincode}), {o.state}</span></div>
              <div className="order-info-item"><label>Seller</label><span>{o.sellerName}</span></div>
              <div className="order-info-item"><label>Booking Date</label><span>{o.BookingDate}</span></div>
              <div className="order-info-item"><label>Delivery By</label><span>{o.Delivery}</span></div>
              <div className="order-info-item"><label>Price</label><span>₹{o.totalamount}</span></div>
              <div className="order-info-item"><label>Status</label><span className="status-badge">{o.status}</span></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
