export default function OrderItem({ order }) {
  return (
    <div className="order-card">
      {order.itemImage
        ? <img src={`/uploads/${order.itemImage}`} alt={order.booktitle} />
        : <div style={{ width: 60, height: 80, background: 'var(--secondary)', borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.5rem', flexShrink: 0 }}>📚</div>
      }
      <div className="order-info">
        <div className="order-info-item"><label>Product Name</label><span>{order.booktitle}</span></div>
        <div className="order-info-item"><label>Order ID</label><span>{order._id?.slice(0, 8)}...</span></div>
        <div className="order-info-item"><label>Address</label><span>{order.flatno}, {order.city}</span></div>
        <div className="order-info-item"><label>Price</label><span>₹{order.totalamount}</span></div>
        <div className="order-info-item"><label>Status</label><span className="status-badge">{order.status}</span></div>
      </div>
    </div>
  );
}
