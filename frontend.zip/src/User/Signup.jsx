import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function Signup() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [err, setErr] = useState('');

  const handleSubmit = async () => {
    try {
      await axios.post('/api/user/signup', form);
      navigate('/user/login');
    } catch (e) {
      setErr(e.response?.data?.message || 'Signup failed');
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h2>User Registration</h2>
        {err && <p style={{ color: 'var(--danger)', textAlign: 'center', fontSize: '0.82rem', marginBottom: '0.75rem' }}>{err}</p>}
        <div className="form-group">
          <label>Name</label>
          <input placeholder="Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
        </div>
        <div className="form-group">
          <label>Email address</label>
          <input type="email" placeholder="Email address" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input type="password" placeholder="Password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
        </div>
        <button className="btn-primary" onClick={handleSubmit}>Signup</button>
        <p className="auth-footer">Already have an account? <a href="/user/login">Login</a></p>
      </div>
    </div>
  );
}
