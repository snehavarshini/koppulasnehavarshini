import { useNavigate } from 'react-router-dom';

export default function Unavbar() {
  const navigate = useNavigate();
  const name = localStorage.getItem('userName') || 'User';

  const logout = () => {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userName');
    navigate('/user/login');
  };

  return (
    <nav className="navbar">
      <a href="/user/home" className="navbar-brand">BookStore</a>
      <ul className="navbar-links">
        <li><a href="/user/home">Home</a></li>
        <li><a href="/user/books">Books</a></li>
        <li><a href="/user/orders">My Orders</a></li>
        <li><button onClick={logout}>Logout</button></li>
        <li>({name})</li>
      </ul>
    </nav>
  );
}
