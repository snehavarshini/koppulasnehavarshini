export default function Footer() {
  return (
    <footer style={{
      background: 'var(--primary)',
      color: 'var(--white)',
      textAlign: 'center',
      padding: '1.25rem',
      fontSize: '0.82rem'
    }}>
      <p>© 2024 BookStore — Your Gateway to Infinite Stories</p>
      <p style={{ marginTop: '0.3rem', opacity: 0.75 }}></p>
    </footer>
  );
}
