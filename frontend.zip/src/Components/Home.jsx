import { useNavigate } from "react-router-dom";
import Footer from "./Footer";

const categories = [
  { icon: "📖", label: "Fiction" },
  { icon: "🔬", label: "Science" },
  { icon: "👤", label: "Biographies" },
  { icon: "🧒", label: "Children's Books" },
];

const features = [
  { icon: "🚚", title: "Fast Delivery", desc: "Get your favorite books delivered quickly to your doorstep." },
  { icon: "💳", title: "Secure Payments", desc: "100% secure payment methods for worry-free shopping." },
  { icon: "📚", title: "Huge Collection", desc: "Thousands of books across every genre and category." },
  { icon: "⭐", title: "Top Rated Sellers", desc: "Purchase books from verified and trusted sellers." },
];

const reviews = [
  { name: "Rahul", review: "Amazing collection of books with fast delivery." },
  { name: "Priya", review: "Simple UI and very easy to purchase books." },
  { name: "Arjun", review: "Loved the seller experience and recommendations." },
];

function SectionTitle({ title }) {
  return (
    <div className="section-divider">
      <div className="divider-line" />
      <div className="divider-inner">
        <span className="divider-dot" />
        <h2 className="landing-title">{title}</h2>
        <span className="divider-dot" />
      </div>
      <div className="divider-line right" />
    </div>
  );
}

export default function Home() {
  const navigate = useNavigate();

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>

      {/* Navbar */}
      <nav className="navbar">
        <span className="navbar-brand">📖 BOOK STORE</span>
        <ul className="navbar-links">
          <li><a href="/user/login">User</a></li>
          <li><a href="/seller/login">Seller</a></li>
          <li><a href="/admin/login">Admin</a></li>
        </ul>
      </nav>

      <div style={{ flex: 1 }}>

        {/* Hero */}
        <div className="home-hero">
          <h1>Your Gateway to Infinite Stories</h1>
          <p>
            Discover captivating books, connect with passionate sellers,
            and fuel your love for reading — only at BookStore.
          </p>
          <button className="hero-btn" onClick={() => navigate("/user/login")}>
            Start Exploring
          </button>
        </div>

        {/* Explore by Category */}
        <div className="home-section">
          <SectionTitle title="Explore by Category" />
          <div className="categories-grid">
            {categories.map((cat) => (
              <div className="landing-card category-style" key={cat.label}>
                <span className="landing-icon">{cat.icon}</span>
                <h3>{cat.label}</h3>
              </div>
            ))}
          </div>
        </div>

        {/* Why Choose BookStore */}
        <div className="home-section" style={{ background: "rgba(255,255,255,0.3)" }}>
          <SectionTitle title="Why Choose BookStore?" />
          <div className="categories-grid">
            {features.map((f) => (
              <div className="landing-card feature-style" key={f.title}>
                <div className="feature-icon-circle">{f.icon}</div>
                <h3>{f.title}</h3>
                <p>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Reviews */}
        <div className="home-section">
          <SectionTitle title="What Our Customers Say" />
          <div className="categories-grid">
            {reviews.map((r) => (
              <div className="landing-card review-style" key={r.name}>
                <span className="quote-mark open-quote">"</span>
                <div style={{ fontSize: "18px", color: "#d4a055", margin: "8px 0" }}>⭐⭐⭐⭐⭐</div>
                <h3>{r.name}</h3>
                <p>{r.review}</p>
                <span className="quote-mark close-quote">"</span>
              </div>
            ))}
          </div>
        </div>

        {/* Contact */}
        <div style={{ textAlign: "center" }}>
          <button className="contact-btn">Contact Us</button>
        </div>

      </div>

      <Footer />
    </div>
  );
}
