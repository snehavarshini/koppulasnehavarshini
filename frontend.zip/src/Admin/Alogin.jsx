import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function Alogin() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [err, setErr] = useState('');

  const handleSubmit = async () => {
    try {
      const res = await axios.post('/api/admin/login', form);
      localStorage.setItem('adminToken', res.data.token);
      localStorage.setItem('adminName', res.data.name);
      navigate('/admin/home');
    } catch (e) {
      setErr(e.response?.data?.message || 'Login failed');
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h2>Login to Admin Account</h2>
        {err && <p style={{ color: 'var(--danger)', textAlign: 'center', fontSize: '0.82rem', marginBottom: '0.75rem' }}>{err}</p>}
        <div className="form-group">
          <label>Email address</label>
          <input type="email" placeholder="Enter your email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input type="password" placeholder="Enter your password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
        </div>
        <button className="btn-primary" onClick={handleSubmit}>Log In</button>
        <p className="auth-footer">Don't have an account? <a href="/admin/signup">Signup</a></p>
      </div>
    </div>
  );
}
