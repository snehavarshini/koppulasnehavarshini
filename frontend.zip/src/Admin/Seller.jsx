import { useEffect, useState } from 'react';
import axios from 'axios';
import Anavbar from './Anavbar';

export default function Seller() {
  const [sellers, setSellers] = useState([]);
  const token = localStorage.getItem('adminToken');

  useEffect(() => {
    axios.get('/api/admin/sellers', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setSellers(res.data))
      .catch(() => {});
  }, []);

  const deleteSeller = async (id) => {
    if (!window.confirm('Delete this seller?')) return;
    await axios.delete(`/api/admin/sellers/${id}`, { headers: { Authorization: `Bearer ${token}` } });
    setSellers(sellers.filter(s => s._id !== id));
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Anavbar />
      <div className="products-page">
        <div className="table-container">
          <h2>Sellers</h2>
          <table>
            <thead>
              <tr>
                <th>Sl.No</th>
                <th>Seller ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Operation</th>
              </tr>
            </thead>
            <tbody>
              {sellers.map((s, i) => (
                <tr key={s._id}>
                  <td>{i + 1}</td>
                  <td style={{ fontSize: '0.72rem' }}>{s._id}</td>
                  <td>{s.name}</td>
                  <td>{s.email}</td>
                  <td>
                    <div className="action-btns">
                      <button className="btn-sm btn-danger" onClick={() => deleteSeller(s._id)}>🗑 Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
              {sellers.length === 0 && <tr><td colSpan={5} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No sellers found</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
