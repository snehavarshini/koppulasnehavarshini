import { useEffect, useState } from 'react';
import axios from 'axios';
import Anavbar from './Anavbar';

export default function Users() {
  const [users, setUsers] = useState([]);
  const [selectedOrders, setSelectedOrders] = useState(null);
  const token = localStorage.getItem('adminToken');

  useEffect(() => {
    axios.get('/api/admin/users', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setUsers(res.data))
      .catch(() => {});
  }, []);

  const deleteUser = async (id) => {
    if (!window.confirm('Delete this user?')) return;
    await axios.delete(`/api/admin/users/${id}`, { headers: { Authorization: `Bearer ${token}` } });
    setUsers(users.filter(u => u._id !== id));
  };

  const viewOrders = async (id) => {
    const res = await axios.get(`/api/admin/users/${id}/orders`, { headers: { Authorization: `Bearer ${token}` } });
    setSelectedOrders(res.data);
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Anavbar />
      <div className="products-page">
        <div className="table-container">
          <h2>Users</h2>
          <table>
            <thead>
              <tr>
                <th>Sl.No</th>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Operation</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u, i) => (
                <tr key={u._id}>
                  <td>{i + 1}</td>
                  <td style={{ fontSize: '0.72rem' }}>{u._id}</td>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td>
                    <div className="action-btns">
                      <button className="btn-sm" style={{ background: '#28a745', color: '#fff' }} onClick={() => viewOrders(u._id)}>✏️</button>
                      <button className="btn-sm btn-danger" onClick={() => deleteUser(u._id)}>🗑</button>
                      <button className="btn-sm" style={{ background: 'var(--secondary)', color: '#fff' }} onClick={() => viewOrders(u._id)}>View Orders</button>
                    </div>
                  </td>
                </tr>
              ))}
              {users.length === 0 && <tr><td colSpan={5} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No users found</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      {/* Orders Modal */}
      {selectedOrders && (
        <div className="modal-overlay" onClick={() => setSelectedOrders(null)}>
          <div className="modal-box" onClick={e => e.stopPropagation()}>
            <h3>User Orders</h3>
            {selectedOrders.length === 0 && <p style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No orders</p>}
            {selectedOrders.map(o => (
              <div key={o._id} style={{ borderBottom: '1px solid var(--border)', padding: '0.75rem 0', fontSize: '0.82rem' }}>
                <p><strong>Product:</strong> {o.booktitle}</p>
                <p><strong>Order ID:</strong> {o._id.slice(0, 8)}...</p>
                <p><strong>Buyer:</strong> {o.userName}</p>
                <p><strong>Address:</strong> {o.flatno}, {o.city} ({o.pincode}), {o.state}</p>
                <p><strong>Price:</strong> <span style={{ color: 'var(--success)' }}>₹{o.totalamount}</span></p>
                <p><strong>Status:</strong> <span className="status-badge">{o.status}</span></p>
              </div>
            ))}
            <div className="modal-footer">
              <button className="btn-danger btn-sm" style={{ padding: '0.5rem 1.5rem' }} onClick={() => setSelectedOrders(null)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
