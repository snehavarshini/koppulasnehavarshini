import { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import axios from 'axios';
import Anavbar from './Anavbar';

export default function Ahome() {
  const [stats, setStats] = useState({ users: 0, sellers: 0, items: 0, orders: 0 });

  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    axios.get('/api/admin/dashboard', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setStats(res.data))
      .catch(() => {});
  }, []);

  const chartData = [
    { name: 'Users', value: stats.users },
    { name: 'Vendors', value: stats.sellers },
    { name: 'Items', value: stats.items },
    { name: 'Orders', value: stats.orders },
  ];

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Anavbar />
      <div className="dashboard-page">
        <h2>Admin Dashboard</h2>
        <div className="stats-grid">
          <div className="stat-card users"><h3>USERS</h3><p>{stats.users}</p></div>
          <div className="stat-card sellers"><h3>Vendors</h3><p>{stats.sellers}</p></div>
          <div className="stat-card items"><h3>Items</h3><p>{stats.items}</p></div>
          <div className="stat-card orders"><h3>Total Orders</h3><p>{stats.orders}</p></div>
        </div>
        <div className="chart-container">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={chartData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#7B3F00" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
