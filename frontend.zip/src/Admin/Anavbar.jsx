import { useNavigate } from 'react-router-dom';

export default function Anavbar() {
  const navigate = useNavigate();
  const name = localStorage.getItem('adminName') || 'Admin';

  const logout = () => {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminName');
    navigate('/admin/login');
  };

  return (
    <nav className="navbar">
      <a href="/admin/home" className="navbar-brand">BookStore (Admin)</a>
      <ul className="navbar-links">
        <li><a href="/admin/home">Home</a></li>
        <li><a href="/admin/users">Users</a></li>
        <li><a href="/admin/sellers">Sellers</a></li>
        <li><button onClick={logout}>Logout</button></li>
        <li>({name})</li>
      </ul>
    </nav>
  );
}
