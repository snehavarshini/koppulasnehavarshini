import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Snavbar from "./Snavbar";

export default function Addbook() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    title: "",
    author: "",
    genre: "",
    price: "",
    description: "",
  });
  const [image, setImage] = useState(null);
  const [msg, setMsg] = useState("");
  const token = localStorage.getItem("sellerToken");

  const handleSubmit = async () => {
    const data = new FormData();
    Object.entries(form).forEach(([k, v]) => data.append(k, v));
    if (image) data.append("itemImage", image);
    try {
      await axios.post("/api/seller/books", data, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });
      setMsg("Book added successfully!");
      setTimeout(() => navigate("/seller/products"), 1200);
    } catch (e) {
      setMsg(e.response?.data?.message || "Failed to add book");
    }
  };

  return (
    <div className="page-wrapper">
      <div className="bg-overlay" />

      <div style={{ position: "relative", zIndex: 1, minHeight: "100vh" }}>
        <Snavbar />

        <div className="auth-page">
          <div className="form-card">
            <h2>Add Book</h2>
            {msg && (
              <p style={{ textAlign: "center", color: "var(--primary)", fontSize: "0.85rem", marginBottom: "0.75rem" }}>
                {msg}
              </p>
            )}
            {["title", "author", "genre", "price", "description"].map((field) => (
              <div className="form-group" key={field}>
                <input
                  placeholder={field.charAt(0).toUpperCase() + field.slice(1)}
                  value={form[field]}
                  onChange={(e) => setForm({ ...form, [field]: e.target.value })}
                />
              </div>
            ))}
            <div className="form-group">
              <label>Item Image</label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => setImage(e.target.files[0])}
              />
            </div>
            <button className="btn-primary" onClick={handleSubmit}>
              Submit
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
