import { useEffect, useState } from 'react';
import axios from 'axios';
import Snavbar from './Snavbar';

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const token = localStorage.getItem('sellerToken');

  useEffect(() => {
    axios.get('/api/seller/orders', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setOrders(res.data))
      .catch(() => {});
  }, []);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Snavbar />
      <div className="orders-page">
        <h2>Orders</h2>
        {orders.length === 0 && <p style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No orders received yet.</p>}
        {orders.map(o => (
          <div className="order-card" key={o._id}>
            {o.itemImage
              ? <img src={`/uploads/${o.itemImage}`} alt={o.booktitle} />
              : <div style={{ width: 60, height: 80, background: 'var(--bg)', borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.5rem', flexShrink: 0 }}>📚</div>
            }
            <div className="order-info">
              <div className="order-info-item"><label>Product Name</label><span>{o.booktitle}</span></div>
              <div className="order-info-item"><label>Order ID</label><span style={{ fontSize: '0.72rem' }}>{o._id.slice(0, 8)}...</span></div>
              <div className="order-info-item"><label>Customer Name</label><span>{o.userName}</span></div>
              <div className="order-info-item"><label>Address</label><span>{o.flatno}, {o.city} ({o.pincode}), {o.state}</span></div>
              <div className="order-info-item"><label>Booking Date</label><span>{o.BookingDate}</span></div>
              <div className="order-info-item"><label>Delivery By</label><span>{o.Delivery}</span></div>
              <div className="order-info-item"><label>Warranty</label><span>1 year</span></div>
              <div className="order-info-item"><label>Price</label><span>₹{o.totalamount}</span></div>
              <div className="order-info-item"><label>Status</label><span className="status-badge">{o.status}</span></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
