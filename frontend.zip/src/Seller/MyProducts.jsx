import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Snavbar from "./Snavbar";

export default function MyProducts() {
  const [books, setBooks] = useState([]);
  const token = localStorage.getItem("sellerToken");
  const navigate = useNavigate();

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const res = await axios.get("/api/seller/books", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setBooks(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const deleteBook = async (id) => {
    if (!window.confirm("Delete this book?")) return;

    try {
      await axios.delete(`/api/seller/books/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setBooks(books.filter((b) => b._id !== id));
    } catch (err) {
      console.log(err);
    }
  };

  return (
    
    <div style={{ minHeight: "100vh", background: "var(--bg)" }}>
      <Snavbar />

      <div className="products-page">
        <h2>Books List</h2>

        {books.length === 0 && (
          <p style={{ textAlign: "center", color: "var(--text-muted)" }}>
            No books yet. <a href="/seller/addbook">Add one!</a>
          </p>
        )}

        <div className="books-grid">
          {books.map((book) => (
            <div className="book-card" key={book._id}>
              {book.itemImage ? (
                <img
                  src={`http://localhost:8000/uploads/${book.itemImage}`}
                  alt={book.title}
                />
              ) : (
                <div
                  style={{
                    width: "100%",
                    height: 180,
                    background: "var(--bg)",
                    borderRadius: 4,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "2.5rem",
                  }}
                >
                  📚
                </div>
              )}

              <div className="book-title">{book.title}</div>

              <div className="book-meta">
                <b>Author:</b> {book.author}
              </div>

              <div className="book-meta">
                <b>Genre:</b> {book.genre}
              </div>

              <div className="book-price">
                <b>Price:</b> ₹ {book.price}
              </div>

              {book.description && (
                <div
                  className="book-meta"
                  style={{ marginTop: "8px" }}
                >
                  {book.description.slice(0, 80)}...
                </div>
              )}

              <div className="book-buttons">
                <button
                  className="hero-btn"
                  onClick={() =>
                    navigate(`/seller/editbook/${book._id}`)
                  }
                >
                  Edit
                </button>

                <button
                  className="contact-btn"
                  onClick={() => deleteBook(book._id)}
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}