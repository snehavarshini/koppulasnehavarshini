import { useNavigate } from 'react-router-dom';

export default function Snavbar() {
  const navigate = useNavigate();
  const name = localStorage.getItem('sellerName') || 'Seller';

  const logout = () => {
    localStorage.removeItem('sellerToken');
    localStorage.removeItem('sellerName');
    navigate('/seller/login');
  };

  return (
    <nav className="navbar">
      <a href="/seller/home" className="navbar-brand">BookStore (Seller)</a>
      <ul className="navbar-links">
        <li><a href="/seller/home">Home</a></li>
        <li><a href="/seller/products">My Products</a></li>
        <li><a href="/seller/addbook">Add Books</a></li>
        <li><a href="/seller/orders">Orders</a></li>
        <li><button onClick={logout}>Logout</button></li>
        <li>({name})</li>
      </ul>
    </nav>
  );
}
