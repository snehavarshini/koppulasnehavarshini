import { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import axios from 'axios';
import Snavbar from './Snavbar';

export default function Shome() {
  const [stats, setStats] = useState({ items: 0, orders: 0 });
  const token = localStorage.getItem('sellerToken');

  useEffect(() => {
    axios.get('/api/seller/dashboard', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setStats(res.data))
      .catch(() => {});
  }, []);

  const chartData = [
    { name: 'Items', value: stats.items },
    { name: 'Orders', value: stats.orders },
  ];

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Snavbar />
      <div className="dashboard-page">
        <h2>Seller Dashboard</h2>
        <div className="stats-grid" style={{ maxWidth: '480px', margin: '0 auto 2rem' }}>
          <div className="stat-card items"><h3>Items</h3><p>{stats.items}</p></div>
          <div className="stat-card orders"><h3>Total Orders</h3><p>{stats.orders}</p></div>
        </div>
        <div className="chart-container" style={{ maxWidth: '600px', margin: '0 auto' }}>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={chartData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#4169e1" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
