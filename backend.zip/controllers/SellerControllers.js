const Seller = require('../models/Seller/Seller');
const Book = require('../models/Seller/Book');
const Order = require('../models/Users/MyOrders');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Seller Signup
exports.signup = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    const exists = await Seller.findOne({ email });

    if (exists)
      return res.status(400).json({ message: 'Seller already exists' });

    const hashed = await bcrypt.hash(password, 10);

    const seller = await Seller.create({
      name,
      email,
      password: hashed,
    });

    res.status(201).json({
      message: 'Seller registered',
      seller,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Seller Login
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const seller = await Seller.findOne({ email });

    if (!seller)
      return res.status(404).json({ message: 'Seller not found' });

    const match = await bcrypt.compare(password, seller.password);

    if (!match)
      return res.status(401).json({ message: 'Invalid credentials' });

    const token = jwt.sign(
      {
        id: seller._id,
        role: 'seller',
        name: seller.name,
      },
      process.env.JWT_SECRET,
      {
        expiresIn: '7d',
      }
    );

    res.json({
      token,
      name: seller.name,
      role: 'seller',
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Add Book
exports.addBook = async (req, res) => {
  try {
    const { title, author, genre, price, description } = req.body;

    const itemImage = req.file ? req.file.filename : '';

    const seller = await Seller.findById(req.user.id);

    const book = await Book.create({
      title,
      author,
      genre,
      price,
      description,
      itemImage,
      sellerId: req.user.id,
      sellerName: seller.name,
    });

    res.status(201).json({
      message: 'Book added',
      book,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get Seller Books
exports.getMyBooks = async (req, res) => {
  try {
    const books = await Book.find({
      sellerId: req.user.id,
    });

    res.json(books);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get Single Book
exports.getBookById = async (req, res) => {
  try {
    const book = await Book.findOne({
      _id: req.params.id,
      sellerId: req.user.id,
    });

    if (!book)
      return res.status(404).json({
        message: 'Book not found',
      });

    res.json(book);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Update Book
exports.updateBook = async (req, res) => {
  try {
    const book = await Book.findOne({
      _id: req.params.id,
      sellerId: req.user.id,
    });

    if (!book)
      return res.status(404).json({
        message: 'Book not found',
      });

    book.title = req.body.title;
    book.author = req.body.author;
    book.genre = req.body.genre;
    book.price = req.body.price;
    book.description = req.body.description;

    if (req.file) {
      book.itemImage = req.file.filename;
    }

    await book.save();

    res.json({
      message: 'Book Updated Successfully',
      book,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Delete Book
exports.deleteBook = async (req, res) => {
  try {
    const book = await Book.findOne({
      _id: req.params.id,
      sellerId: req.user.id,
    });

    if (!book)
      return res.status(404).json({
        message: 'Book not found',
      });

    await book.deleteOne();

    res.json({
      message: 'Book deleted successfully',
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get Orders
exports.getOrders = async (req, res) => {
  try {
    const orders = await Order.find({
      sellerId: req.user.id,
    });

    res.json(orders);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Dashboard
exports.getDashboard = async (req, res) => {
  try {
    const items = await Book.countDocuments({
      sellerId: req.user.id,
    });

    const orders = await Order.countDocuments({
      sellerId: req.user.id,
    });

    res.json({
      items,
      orders,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};