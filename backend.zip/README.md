# 📚 BookStore – MERN Stack Application

A full-stack BookStore web application built with MongoDB, Express.js, React, and Node.js.

---

## 🗂 Project Structure

```
BookStore/
├── client/          # React frontend (Vite)
└── server/          # Node.js + Express backend
```

---

## ⚙️ Prerequisites

- Node.js v16 or above
- MongoDB (running locally on port 27017)
- npm v8 or above

---

## 🚀 Setup & Run

### 1. Clone / Extract the project

### 2. Setup Server (Backend)

```bash
cd server
npm install
```

Create a `.env` file (already included):
```
PORT=8000
MONGO_URI=mongodb://localhost:27017/bookstore
JWT_SECRET=bookstore_jwt_secret_key_2024
```

Start the server:
```bash
npm run dev
# or
npm start
```

Server runs on: **http://localhost:8000**

---

### 3. Setup Client (Frontend)

```bash
cd client
npm install
npm run dev
```

Frontend runs on: **http://localhost:5173**

---

## 👤 User Roles & Routes

### 🌐 Public Landing Page
- `http://localhost:5173/` – Home page with categories

### 👑 Admin
| Page | URL |
|------|-----|
| Signup | `/admin/signup` |
| Login | `/admin/login` |
| Dashboard | `/admin/home` |
| Manage Users | `/admin/users` |
| Manage Sellers | `/admin/sellers` |

### 🏪 Seller
| Page | URL |
|------|-----|
| Signup | `/seller/signup` |
| Login | `/seller/login` |
| Dashboard | `/seller/home` |
| My Products | `/seller/products` |
| Add Book | `/seller/addbook` |
| Orders | `/seller/orders` |

### 📖 User
| Page | URL |
|------|-----|
| Signup | `/user/signup` |
| Login | `/user/login` |
| Home | `/user/home` |
| Browse Books | `/user/books` |
| Book Detail | `/user/books/:id` |
| My Orders | `/user/orders` |

---

## 🎨 Theme

- **Primary Color:** Brown (`#7B3F00`)
- **Background:** Warm Beige (`#fdf6e3`)
- **Accent:** Golden (`#d4a055`)
- **Fully Responsive** – Mobile & Desktop

---

## 📦 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React.js (Vite), React Router, Recharts |
| Backend | Node.js, Express.js |
| Database | MongoDB, Mongoose |
| Auth | JWT, bcryptjs |
| File Upload | Multer |

---

## 📡 API Endpoints

### Admin
- `POST /api/admin/signup`
- `POST /api/admin/login`
- `GET /api/admin/dashboard`
- `GET /api/admin/users`
- `DELETE /api/admin/users/:id`
- `GET /api/admin/users/:id/orders`
- `GET /api/admin/sellers`
- `DELETE /api/admin/sellers/:id`

### Seller
- `POST /api/seller/signup`
- `POST /api/seller/login`
- `GET /api/seller/dashboard`
- `POST /api/seller/books`
- `GET /api/seller/books`
- `DELETE /api/seller/books/:id`
- `GET /api/seller/orders`

### User
- `POST /api/user/signup`
- `POST /api/user/login`
- `GET /api/user/books`
- `GET /api/user/books/:id`
- `POST /api/user/orders`
- `GET /api/user/orders`
