const express = require('express');
const router = express.Router();

const {
  signup,
  login,
  addBook,
  getMyBooks,
  deleteBook,
  getOrders,
  getDashboard,
  getBookById,      // NEW
  updateBook        // NEW
} = require('../controllers/SellerControllers');

const authMiddleware = require('../middlewares/authMiddleware');
const upload = require('../middlewares/upload');

router.post('/signup', signup);
router.post('/login', login);

router.get('/dashboard', authMiddleware, getDashboard);

// Book APIs
router.post('/books', authMiddleware, upload.single('itemImage'), addBook);

router.get('/books', authMiddleware, getMyBooks);

// NEW
router.get('/books/:id', authMiddleware, getBookById);

// NEW
router.put('/books/:id', authMiddleware, upload.single('itemImage'), updateBook);

router.delete('/books/:id', authMiddleware, deleteBook);

router.get('/orders', authMiddleware, getOrders);

module.exports = router;