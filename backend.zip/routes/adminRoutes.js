const express = require('express');
const router = express.Router();
const { signup, login, getDashboard, getUsers, deleteUser, getUserOrders, getSellers, deleteSeller } = require('../controllers/AdminControllers');
const authMiddleware = require('../middlewares/authMiddleware');

router.post('/signup', signup);
router.post('/login', login);
router.get('/dashboard', authMiddleware, getDashboard);
router.get('/users', authMiddleware, getUsers);
router.delete('/users/:id', authMiddleware, deleteUser);
router.get('/users/:id/orders', authMiddleware, getUserOrders);
router.get('/sellers', authMiddleware, getSellers);
router.delete('/sellers/:id', authMiddleware, deleteSeller);

module.exports = router;
