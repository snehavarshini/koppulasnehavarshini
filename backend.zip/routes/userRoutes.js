const express = require('express');
const router = express.Router();
const { signup, login, getAllBooks, getBook, placeOrder, getMyOrders } = require('../controllers/UsersController');
const authMiddleware = require('../middlewares/authMiddleware');

router.post('/signup', signup);
router.post('/login', login);
router.get('/books', getAllBooks);
router.get('/books/:id', getBook);
router.post('/orders', authMiddleware, placeOrder);
router.get('/orders', authMiddleware, getMyOrders);

module.exports = router;
